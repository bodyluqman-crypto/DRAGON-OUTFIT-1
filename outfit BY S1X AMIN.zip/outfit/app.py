from flask import Flask, request, send_file, jsonify
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
import requests
import math
import time

app = Flask(__name__)
session = requests.Session()

# ---------------------------
# Keys API
# ---------------------------
API_KEYS = {"S1X-TEAM": 9999}
HEADERS = {'User-Agent': 'Mozilla/5.0 (compatible; MyBot/1.0)'}
ICON_URL = "https://www.dl.cdn.freefireofficial.com/icons/{}.png"

def is_valid_key(key):
    return key in API_KEYS and API_KEYS[key] > 0

def consume_key(key):
    if API_KEYS[key] > 0:
        API_KEYS[key] -= 1

def fetch_image(id_, size=None):
    if not id_:
        return None
    url = ICON_URL.format(id_)
    for attempt in range(3):
        try:
            r = session.get(url, timeout=10, headers=HEADERS, verify=False)  # تجاهل SSL
            if r.status_code == 200 and r.content:
                img = Image.open(BytesIO(r.content)).convert("RGBA")
                if size:
                    img = img.resize(size, Image.LANCZOS)
                return img
        except Exception as e:
            print(f"⚠️ Error fetching image {id_}: {e}")
        time.sleep(1)
    return None

def filter_valid_ids(items):
    return [i for i in items if isinstance(i, int) and i > 100000000]

# ---------------------------
# Composite Image
# ---------------------------
def create_composite(data):
    bg_w, bg_h = 1800, 1800
    bg = Image.new("RGBA", (bg_w, bg_h), (135, 206, 250, 255))  # خلفية أزرق فاتح
    draw = ImageDraw.Draw(bg)

    skin_size = (220, 220)
    border_thickness = 12
    corner_radius = 30

    result = data.get("result", {})
    basic_info = result.get("basic_info", {})
    profile_info = result.get("profile_info", {})
    pet_info = result.get("pet_info", {})

    avatar_id = profile_info.get("avatar_id")
    clothes = profile_info.get("clothes", [])
    skills = profile_info.get("equiped_skills", [])
    weapons = basic_info.get("weapon_skin_shows", [])
    pet_id = pet_info.get("id") if pet_info.get("is_selected") else None
    nickname = basic_info.get("nickname", "Player")

    all_items_raw = clothes + skills + weapons
    all_items = filter_valid_ids(all_items_raw)
    if pet_id and pet_id > 100000000:
        all_items.append(pet_id)

    center_x, center_y = bg_w // 2, bg_h // 2

    # Avatar in center
    avatar_img = fetch_image(avatar_id, size=(300, 300)) if avatar_id else None
    if avatar_img:
        frame = Image.new("RGBA", (avatar_img.width + border_thickness*2, avatar_img.height + border_thickness*2), (0,0,0,0))
        frame_draw = ImageDraw.Draw(frame)
        for i in range(border_thickness):
            color = (255-int(255*i/border_thickness), int(255*i/border_thickness),0,255)
            frame_draw.rounded_rectangle([i,i,frame.width-i-1, frame.height-i-1], radius=corner_radius, outline=color, width=2)
        frame.paste(avatar_img, (border_thickness, border_thickness), avatar_img)
        bg.paste(frame, (center_x-frame.width//2, center_y-frame.height//2), frame)

    # Arrange items in circle
    radius = 600
    n = len(all_items) if all_items else 1
    for idx, item_id in enumerate(all_items):
        angle = 2*math.pi*idx/n
        x = int(center_x + radius * math.cos(angle))
        y = int(center_y + radius * math.sin(angle))
        item_img = fetch_image(item_id, size=skin_size)
        if item_img:
            frame = Image.new("RGBA", (item_img.width+border_thickness*2, item_img.height+border_thickness*2), (0,0,0,0))
            frame_draw = ImageDraw.Draw(frame)
            for i in range(border_thickness):
                color = (255-int(255*i/border_thickness), int(255*i/border_thickness),0,255)
                frame_draw.rounded_rectangle([i,i,frame.width-i-1, frame.height-i-1], radius=corner_radius, outline=color, width=2)
            frame.paste(item_img,(border_thickness,border_thickness), item_img)
            bg.paste(frame,(x-frame.width//2, y-frame.height//2), frame)

    # كتابة اسم اللاعب أسفل الصورة
    try:
        font_name = ImageFont.truetype("arial.ttf", 90)
    except:
        font_name = ImageFont.load_default()

    bbox = draw.textbbox((0,0), nickname, font=font_name)
    text_w = bbox[2]-bbox[0]
    text_x = center_x - text_w//2
    text_y = center_y + 200
    draw.text((text_x, text_y), nickname, font=font_name, fill=(0,0,0,255))

    return bg

# ---------------------------
# Routes
# ---------------------------
@app.route("/")
def index():
    return "✅ Free Fire Outfit API Ready!"

@app.route("/addkey/<key>/<int:limit>")
def add_key(key, limit):
    API_KEYS[key] = limit
    return jsonify({"status": "✅ Key added", "key": key, "limit": limit})

@app.route("/outfit", methods=["GET"])
def render():
    uid = request.args.get("uid")
    key = request.args.get("key")
    if not key or not is_valid_key(key):
        return jsonify({"error": "Unauthorized or invalid key"}), 403
    if not uid:
        return jsonify({"error": "Missing uid"}), 400
    try:
        url = f"https://bimoallapis.vercel.app/all/{uid}"
        r = session.get(url, timeout=20, headers=HEADERS, verify=False)
        if r.status_code != 200: 
            return jsonify({"error": "Failed to fetch player info"}), 502
        data = r.json()
        if not data.get("result"):
            return jsonify({"error": "Player not found"}), 404

        img = create_composite(data)
        img_io = BytesIO()
        img.convert("RGB").save(img_io, 'JPEG', quality=95)
        img_io.seek(0)
        consume_key(key)
        return send_file(img_io, mimetype='image/jpeg')
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__=="__main__":
    app.run(host="0.0.0.0", port=5000)